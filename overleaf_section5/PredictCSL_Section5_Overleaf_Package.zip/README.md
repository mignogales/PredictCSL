# Overleaf package: Section 5

Upload `section5_zero_shot_predictor.tex` and the three PDF figures in
`figures/`, preserving that subdirectory. Include the section with:

```tex
\input{section5_zero_shot_predictor}
```

The manuscript preamble needs:

```tex
\usepackage{amsmath}
\usepackage{booktabs}
\usepackage{graphicx}
```

The text assumes the labels `sec:real-context`, `sec:context-mechanisms`, and
`eq:normalized-mase` from Sections 3--4.

## Figures

- `fig1_zero_shot_pipeline.pdf`: synthetic labeling and zero-shot deployment.
- `fig2_chronos_objective_operating_points.pdf`: Chronos2-Small target-design
  operating points against selected oracle references.
- `fig3_zero_shot_multimodel.pdf`: 11-model Patch-Transformer/Mamba scope.

PNG twins are included for quick inspection. Run `generate_figures.py` to
regenerate both formats from `data/frozen/`.

## Frozen evidence

- `zero_shot_multimodel.csv`: 22 complete model/backbone rows, each covering the
  official 97 GiftEval cells and 371,330 forecast instances.
- `chronos2_small_objectives.csv`: five synthetic-only training targets.
- `oracle_reference_points.csv`: selected supported cell-oracle points used only
  for diagnostic comparison.
- `mamba_predictor_overhead.csv`: analytic selector parameter/MAC audit at
  horizon 48.
- `chronos2_small_topk.csv`: the five best durable checkpoints for each curve
  backbone, ranked exclusively by synthetic validation regret.
- `source_inventory.csv`: remote source paths and SHA-256 hashes frozen on
  2026-08-12.

Run `validate_frozen_claims.py` before packaging. It checks the cohort,
headline values, positive-model counts, objective ordering, checkpoint spread,
and overhead range.

## Evidential scope and accounting

- Every predictor is trained on synthetic labels produced by its own frozen
  TSFM. No GiftEval values enter training or checkpoint selection.
- The deployment action is dataset--term shared: it averages unlabeled
  per-series score curves before selecting one window. It is not an online
  single-series policy.
- The 11-model comparison covers curve regression only. The four alternative
  targets were evaluated end-to-end only for Chronos2-Small and are explicitly
  framed as post-hoc target-design evidence.
- Reported FLOPs and measured time are for the TSFM forecast stage. They exclude
  predictor inference; the separate overhead table prevents those values from
  being presented as end-to-end savings.
- TiRex internally pads to a fixed context, so its theoretical context FLOPs
  reduction is not a realized hardware-saving claim.
- Positive normalized-MASE transfer occurs for 2/11 Mamba selectors and 2/11
  Patch-Transformer selectors. The section deliberately reports the nine
  negative Mamba results.

The package is intentionally a calibrated proof-of-concept section. It should
not be summarized as a universally safe zero-shot controller.
