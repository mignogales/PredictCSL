from __future__ import annotations

from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
FROZEN = ROOT / "overleaf_section4" / "data" / "frozen"
RAW = ROOT / "overleaf_section4" / "data" / "frozen_input"
OUT = ROOT / "overleaf_section4" / "figures" / "visual_draft"

MODEL_ORDER = [
    "Chronos2-Base",
    "Chronos2-Small",
    "Chronos2-Synth",
    "ChronosBolt-Base",
    "Moirai2-Small",
    "PatchTST-FM-R1",
    "Sundial-Base-128M",
    "TimesFM2.5-200M",
]

DISPLAY = {
    "Chronos2-Base": "Chronos2 Base",
    "Chronos2-Small": "Chronos2 Small",
    "Chronos2-Synth": "Chronos2 Synth",
    "ChronosBolt-Base": "Chronos-Bolt Base",
    "Moirai2-Small": "Moirai 2 Small",
    "PatchTST-FM-R1": "PatchTST-FM",
    "Sundial-Base-128M": "Sundial 128M",
    "TimesFM2.5-200M": "TimesFM 2.5",
    "FlowState-R1": "FlowState R1",
    "TiRex2": "TiRex 2",
    "Toto-2.0-313m": "Toto 2.0",
}

INK = "#243447"
SLICE = "#263238"
FULL = "#C74B50"
TAIL = "#128C8C"
GRID = "#D8DEE6"
BLUE = "#2E74B5"
GOLD = "#A97500"


def configure() -> None:
    mpl.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 10,
            "axes.titlesize": 10.5,
            "axes.labelsize": 9.5,
            "axes.titleweight": "semibold",
            "axes.edgecolor": "#AAB4C0",
            "axes.linewidth": 0.8,
            "xtick.labelsize": 8.5,
            "ytick.labelsize": 8.5,
            "legend.fontsize": 9,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "savefig.facecolor": "white",
            "savefig.bbox": "tight",
            "savefig.pad_inches": 0.08,
        }
    )


def save(fig: plt.Figure, stem: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f"{stem}.png", dpi=260)
    fig.savefig(OUT / f"{stem}.pdf")
    plt.close(fig)


def context_error_curve() -> None:
    df = pd.read_csv(FROZEN / "chronos2_small_exp1_curve.csv").sort_values("context_length")
    x = df["context_length"].to_numpy()
    y = df["mean_mae"].to_numpy()
    best_idx = int(np.argmin(y))
    best_x, best_y = int(x[best_idx]), float(y[best_idx])
    threshold = 1.05 * best_y
    enough_x = int(x[np.flatnonzero(y <= threshold)[0]])

    fig, ax = plt.subplots(figsize=(7.6, 3.7))
    ax.plot(x, y, color=BLUE, lw=2.4, marker="o", ms=4.2, zorder=3)
    ax.axhspan(best_y, threshold, color=BLUE, alpha=0.10, lw=0)
    ax.axvline(enough_x, color=GOLD, lw=1.6, ls="--")
    ax.scatter([best_x], [best_y], color=INK, s=42, zorder=4)
    ax.annotate(
        f"first within 5%: {enough_x:,}",
        xy=(enough_x, np.interp(enough_x, x, y)),
        xytext=(740, 0.48),
        arrowprops={"arrowstyle": "-", "color": GOLD, "lw": 1.1},
        color=GOLD,
        fontsize=9.5,
        weight="semibold",
    )
    ax.annotate(
        f"minimum: {best_y:.3f} at {best_x:,}",
        xy=(best_x, best_y),
        xytext=(3600, 0.385),
        arrowprops={"arrowstyle": "-", "color": INK, "lw": 1.0},
        color=INK,
        fontsize=9,
    )
    ax.set_xscale("log", base=2)
    ticks = [32, 64, 128, 256, 512, 1024, 2048, 4096, 8192]
    ax.set_xticks(ticks, ["32", "64", "128", "256", "512", "1k", "2k", "4k", "8k"])
    ax.set_xlabel("Context length (timesteps)")
    ax.set_ylabel("Mean forecast MAE")
    ax.grid(True, which="major", color=GRID, lw=0.7, alpha=0.8)
    ax.spines[["top", "right"]].set_visible(False)
    ax.text(
        0.01,
        0.04,
        "Shaded band: within 5% of the observed minimum",
        transform=ax.transAxes,
        color="#667085",
        fontsize=8.5,
    )
    fig.suptitle(
        "Chronos2 Small: forecast error saturates before the maximum context",
        x=0.075,
        y=1.01,
        ha="left",
        color=INK,
        fontsize=12,
        weight="semibold",
    )
    fig.tight_layout()
    save(fig, "fig0_context_saturation_chronos2_small")


def load_exp7_raw() -> pd.DataFrame:
    frames = []
    for path in sorted(RAW.glob("*/exp7_context_decomposition/synthetic/w*/results.csv")):
        frame = pd.read_csv(path)
        frame = frame[frame["metric"].eq("mae")].copy()
        frame["visible_suffix"] = frame["block_index"].astype(int)
        frames.append(frame)
    if not frames:
        raise FileNotFoundError("No frozen Exp7 result files were found")
    return pd.concat(frames, ignore_index=True)


def slicing_vs_masking() -> None:
    raw = load_exp7_raw()
    agg = (
        raw.groupby(
            ["model", "context_length", "visible_suffix", "perturbation_type"],
            as_index=False,
        )[["clean_loss", "intervened_loss"]]
        .mean()
    )

    fig, axes = plt.subplots(2, 4, figsize=(12.8, 6.5), constrained_layout=False)
    for ax, model in zip(axes.flat, MODEL_ORDER):
        sub = agg[agg["model"].eq(model)].sort_values("visible_suffix")
        if sub.empty:
            ax.set_visible(False)
            continue
        full = sub[sub["perturbation_type"].eq("attention_mask/full_history_stats")]
        tail = sub[sub["perturbation_type"].eq("attention_mask/tail_matched_stats")]
        clean = (
            sub.groupby("visible_suffix", as_index=False)["clean_loss"]
            .mean()
            .sort_values("visible_suffix")
        )
        ax.plot(clean["visible_suffix"], clean["clean_loss"], color=SLICE, lw=2.3, label="Physical slice", zorder=4)
        ax.plot(full["visible_suffix"], full["intervened_loss"], color=FULL, lw=1.9, label="Mask: full-history stats", zorder=4)
        ax.plot(
            tail["visible_suffix"],
            tail["intervened_loss"],
            color=TAIL,
            lw=1.9,
            ls="--",
            marker="o",
            ms=2.7,
            markevery=2,
            markerfacecolor="white",
            markeredgewidth=0.9,
            label="Mask: tail-matched stats",
            zorder=7,
        )
        ax.fill_between(
            full["visible_suffix"].to_numpy(),
            clean.set_index("visible_suffix").loc[full["visible_suffix"], "clean_loss"].to_numpy(),
            full["intervened_loss"].to_numpy(),
            color=FULL,
            alpha=0.10,
            lw=0,
        )
        ax.set_xscale("log", base=2)
        xmax = int(sub["visible_suffix"].max())
        tick_candidates = [32, 128, 512, 2048, 8192]
        ticks = [t for t in tick_candidates if t <= xmax]
        labels = ["32", "128", "512", "2k", "8k"][: len(ticks)]
        ax.set_xticks(ticks, labels)
        ax.grid(True, color=GRID, lw=0.65, alpha=0.7)
        ax.spines[["top", "right"]].set_visible(False)
        ax.set_title(DISPLAY[model], loc="left", color=INK, pad=5)
        ax.text(
            0.98,
            0.94,
            f"W={int(sub['context_length'].max()):,}",
            transform=ax.transAxes,
            ha="right",
            va="top",
            color="#667085",
            fontsize=8,
        )
        ax.margins(x=0.03, y=0.08)

    for ax in axes[:, 0]:
        ax.set_ylabel("Mean MAE")
    for ax in axes[-1, :]:
        ax.set_xlabel("Visible suffix")

    handles, labels = axes.flat[0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="upper center",
        ncol=3,
        frameon=False,
        bbox_to_anchor=(0.5, 0.955),
        handlelength=2.7,
        columnspacing=1.7,
    )
    fig.suptitle(
        "Tail-stat matching sharply narrows the slicing–masking gap",
        x=0.055,
        y=1.005,
        ha="left",
        color=INK,
        fontsize=13,
        weight="semibold",
    )
    fig.text(
        0.055,
        0.962,
        "Each panel uses its own MAE scale; compare methods within a model.",
        color="#667085",
        fontsize=9,
    )
    fig.subplots_adjust(left=0.065, right=0.995, bottom=0.09, top=0.87, wspace=0.28, hspace=0.34)
    save(fig, "fig3_slicing_vs_masking_all_models")


def lag_tracking_with_toto_placeholder() -> None:
    controls = pd.read_csv(FROZEN / "exp4_controls.csv")
    summary = pd.read_csv(FROZEN / "exp4_lag_tracking_summary.csv")
    complete = set(summary["model"])
    models = list(summary["model"])
    data = controls[
        controls["model"].isin(complete)
        & controls["family"].eq("B")
        & controls["design_role"].eq("core")
        & controls["strength"].isin([0.5, 1.0])
        & ~controls["config_broken"].astype(bool)
    ].copy()

    colors = plt.get_cmap("tab10").colors
    markers = ("o", "s", "^", "D", "v", "P", "X", "<", ">", "h")
    lags = np.array([32, 64, 128, 256])
    fig = plt.figure(figsize=(12.8, 7.15))
    grid = fig.add_gridspec(
        2, 2, width_ratios=(1.35, 1.0), wspace=0.24, hspace=0.24,
    )
    short_axes = [fig.add_subplot(grid[0, 0]), fig.add_subplot(grid[1, 0])]
    long_ax = fig.add_subplot(grid[:, 1])
    for panel, ax, strength in zip(("A", "B"), short_axes, [0.5, 1.0]):
        subset = data[data["strength"].eq(strength)]
        for idx, model in enumerate(models):
            group = subset[subset["model"].eq(model)].sort_values("lag")
            ax.plot(
                group["lag"],
                group["sufficient_context"],
                marker=markers[idx],
                ms=4.2,
                lw=1.45,
                color=colors[idx],
                label=DISPLAY.get(model, model),
            )
        ax.plot(lags, lags, ls="--", lw=1.25, color="#667085", label="Exact recovery")
        ax.set_xscale("log", base=2)
        ax.set_yscale("log", base=2)
        ax.set_yticks([32, 64, 128, 256, 512, 1024], ["32", "64", "128", "256", "512", "1,024"])
        ax.set_ylabel("5% sufficient context")
        ax.grid(True, which="major", color=GRID, lw=0.7, alpha=0.75)
        ax.spines[["top", "right"]].set_visible(False)
        ax.text(
            0.015,
            0.93,
            f"Dependency strength α = {strength:g}",
            transform=ax.transAxes,
            ha="left",
            va="top",
            color=INK,
            fontsize=10.5,
            weight="semibold",
            bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.84, "pad": 2.5},
        )
        ax.text(
            -0.105, 1.04, panel, transform=ax.transAxes, color=INK,
            fontsize=12, weight="bold", va="top",
        )

    short_axes[-1].set_xticks(lags, ["32", "64", "128", "256"])
    short_axes[-1].set_xlabel("Planted dependency lag (timesteps)")
    short_axes[0].tick_params(labelbottom=False)
    handles, labels = short_axes[0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="upper left",
        ncol=6,
        frameon=False,
        bbox_to_anchor=(0.055, 0.914),
        fontsize=7.8,
        handlelength=1.9,
        columnspacing=1.05,
    )

    long_data = pd.read_csv(FROZEN / "exp4_long_lag_toto.csv")
    long_lags = np.array([128, 512, 1024, 2048])
    for strength, color, marker, line_style in [
        (0.5, GOLD, "s", "--"),
        (1.0, BLUE, "o", "-"),
    ]:
        group = long_data[long_data["strength"].eq(strength)].sort_values("lag")
        long_ax.plot(
            group["lag"], group["sufficient_context"],
            color=color, marker=marker, ms=6.0, lw=2.1, ls=line_style,
            markerfacecolor="white" if strength == 0.5 else color,
            markeredgewidth=1.2,
            label=f"Toto, α={strength:g}", zorder=4,
        )
    long_ax.plot(
        long_lags, long_lags, ls=":", lw=1.5, color="#667085",
        label="Exact recovery", zorder=2,
    )
    long_ax.set_xscale("log", base=2)
    long_ax.set_yscale("log", base=2)
    long_ax.set_xticks(long_lags, ["128", "512", "1,024", "2,048"])
    long_ax.set_yticks(
        [128, 256, 512, 1024, 2048, 4096],
        ["128", "256", "512", "1,024", "2,048", "4,096"],
    )
    long_ax.set_xlabel("Planted dependency lag (timesteps)")
    long_ax.set_ylabel("5% sufficient context")
    long_ax.grid(True, which="major", color=GRID, lw=0.7, alpha=0.75)
    long_ax.spines[["top", "right"]].set_visible(False)
    long_ax.legend(loc="lower right", frameon=False, fontsize=8.4)
    long_ax.text(
        0.99, 1.02, "C", transform=long_ax.transAxes, color=INK,
        fontsize=12, weight="bold", va="top", ha="right",
    )
    long_ax.text(
        0.02, 0.98, "PROVISIONAL · TOTO ONLY",
        transform=long_ax.transAxes, ha="left", va="top",
        color=GOLD, fontsize=9.5, weight="bold",
        bbox={"facecolor": "#FFF7DF", "edgecolor": GOLD, "alpha": 0.95, "pad": 4},
    )
    long_ax.text(
        0.02, 0.895, "Comparator runs pending",
        transform=long_ax.transAxes, ha="left", va="top",
        color="#667085", fontsize=8.6,
    )
    fig.suptitle(
        "Adaptive reach on the completed grid and a provisional long-lag extension",
        x=0.055,
        y=0.995,
        ha="left",
        color=INK,
        fontsize=13,
        weight="semibold",
    )
    fig.text(
        0.055,
        0.955,
        "Panels A–B: 10 models at lags 32–256.  Panel C: Toto only at lags 128–2,048 (48 series per condition).",
        color="#667085",
        fontsize=9,
    )
    fig.subplots_adjust(left=0.075, right=0.99, bottom=0.09, top=0.78)
    save(fig, "fig2_sufficient_context_vs_lag_with_toto_placeholder")


def masking_gap_heatmap() -> None:
    profiles = pd.read_csv(FROZEN / "exp7_decomposition_profiles.csv")
    profiles = profiles[profiles["metric"].eq("mae")].copy()
    suffixes = sorted(profiles["visible_suffix"].unique())
    variants = [
        ("attention_mask/full_history_stats", "Mask retains full-history statistics"),
        ("attention_mask/tail_matched_stats", "Mask uses tail-matched statistics"),
    ]
    matrices = []
    for variant, _ in variants:
        pivot = (
            profiles[profiles["variant"].eq(variant)]
            .pivot(index="model", columns="visible_suffix", values="mean_abs_loss_delta")
            .reindex(index=MODEL_ORDER, columns=suffixes)
        )
        matrices.append(pivot.to_numpy(dtype=float))

    finite = np.concatenate([m[np.isfinite(m)] for m in matrices])
    positive = finite[finite > 0]
    vmin = max(1e-5, float(np.nanpercentile(positive, 1)))
    vmax = float(np.nanpercentile(positive, 99))

    fig, axes = plt.subplots(1, 2, figsize=(12.5, 4.4), gridspec_kw={"wspace": 0.07})
    cmap = mpl.colormaps["magma"].copy()
    cmap.set_bad("#EEF1F5")
    images = []
    for idx, (ax, matrix, (_, title)) in enumerate(zip(axes, matrices, variants)):
        img = ax.imshow(matrix, aspect="auto", cmap=cmap, norm=LogNorm(vmin=vmin, vmax=vmax))
        images.append(img)
        ax.set_title(title, loc="left", color=INK, pad=9)
        ax.set_xticks(np.arange(len(suffixes)))
        tick_labels = []
        for s in suffixes:
            if s >= 1024:
                tick_labels.append(f"{s // 1024}k" if s % 1024 == 0 else f"{s / 1024:g}k")
            else:
                tick_labels.append(str(s))
        ax.set_xticklabels(tick_labels, rotation=55, ha="right")
        ax.set_xlabel("Visible suffix")
        ax.set_yticks(np.arange(len(MODEL_ORDER)))
        if idx == 0:
            ax.set_yticklabels([DISPLAY[m] for m in MODEL_ORDER])
        else:
            ax.set_yticklabels([])
            ax.tick_params(axis="y", length=0)
        ax.set_xticks(np.arange(-0.5, len(suffixes), 1), minor=True)
        ax.set_yticks(np.arange(-0.5, len(MODEL_ORDER), 1), minor=True)
        ax.grid(which="minor", color="white", linewidth=0.55, alpha=0.7)
        ax.tick_params(which="minor", bottom=False, left=False)
        for spine in ax.spines.values():
            spine.set_visible(False)

    fig.subplots_adjust(left=0.19, right=0.89, bottom=0.19, top=0.84)
    cax = fig.add_axes([0.915, 0.20, 0.015, 0.64])
    cbar = fig.colorbar(images[-1], cax=cax)
    cbar.set_label("Mean |MAE(mask) − MAE(slice)|", color=INK)
    cbar.ax.tick_params(labelsize=8)
    fig.suptitle(
        "Tail-matching removes most of the masking–slicing gap",
        x=0.07,
        y=1.02,
        ha="left",
        color=INK,
        fontsize=13,
        weight="semibold",
    )
    fig.text(
        0.07,
        0.96,
        "Log color scale; pale cells at the right are unavailable suffixes for shorter-context models.",
        color="#667085",
        fontsize=9,
    )
    save(fig, "fig4_masking_gap_heatmap_all_models")


def main() -> None:
    configure()
    context_error_curve()
    lag_tracking_with_toto_placeholder()
    slicing_vs_masking()
    masking_gap_heatmap()
    print(f"Wrote visual-draft figures to {OUT}")


if __name__ == "__main__":
    main()
